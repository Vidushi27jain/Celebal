const express = require('express');
const bodyParser = require('body-parser');
const { check, validationResult } = require('express-validator');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = 3000;
const SECRET_KEY = 'your_secret_key';  

app.use(bodyParser.json());

// Dummy data
let users = [
  { id: 1, name: 'Aarjav', email: 'aarjav@example.com', password: bcrypt.hashSync('pass12334', 8), role: 'admin' },
  { id: 2, name: 'Ishika', email: 'isha@example.com', password: bcrypt.hashSync('heelo5678', 8), role: 'user' },
];


const router = express.Router();
const verifyToken = (req, res, next) => {
  const token = req.headers['x-access-token'];
  if (!token) {
    return res.status(403).send({ auth: false, message: 'No token provided.' });
  }
  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) {
      return res.status(500).send({ auth: false, message: 'Failed to authenticate token.' });
    }
    req.userId = decoded.id;
    req.userRole = decoded.role;
    next();
  });
};

const isAdmin = (req, res, next) => {
  if (req.userRole !== 'admin') {
    return res.status(403).send({ message: 'Admin access required.' });
  }
  next();
};
app.use((err, req, res, next) => {
  if (err) {
    res.status(err.status || 500).json({
      error: {
        message: err.message,
      },
    });
  }
  next();
});


router.get('/', [verifyToken, isAdmin], (req, res) => {
  res.json(users);
});


router.get('/:id', verifyToken, (req, res) => {
  const user = users.find(u => u.id == req.params.id);
  if (user) {
    res.json(user);
  } else {
    res.status(404).send('User not found');
  }
});


router.post(
  '/',
  [
    check('name').isLength({ min: 1 }).withMessage('Name is required'),
    check('email').isEmail().withMessage('Valid email is required'),
    check('password').isLength({ min: 6 }).withMessage('Password should be at least 6 characters long'),
  ],
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const hashedPassword = bcrypt.hashSync(req.body.password, 8);
    const newUser = {
      id: users.length + 1,
      name: req.body.name,
      email: req.body.email,
      password: hashedPassword,
      role: req.body.role || 'user', 
    };
    users.push(newUser);
    const token = jwt.sign({ id: newUser.id, role: newUser.role }, SECRET_KEY, { expiresIn: 86400 }); 
    res.status(201).json({ auth: true, token: token });
  }
);


router.put(
  '/:id',
  verifyToken,
  [
    check('name').isLength({ min: 1 }).withMessage('Name is required'),
    check('email').isEmail().withMessage('Valid email is required'),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const user = users.find(u => u.id == req.params.id);
    if (user) {
      user.name = req.body.name;
      user.email = req.body.email;
      res.json(user);
    } else {
      res.status(404).send('User not found');
    }
  }
);


router.delete('/:id', [verifyToken, isAdmin], (req, res) => {
  users = users.filter(u => u.id != req.params.id);
  res.status(204).send();
});


app.post('/login', (req, res, next) => {
  const user = users.find(u => u.email === req.body.email);
  if (!user) {
    return res.status(404).send('No user found.');
  }
  const passwordIsValid = bcrypt.compareSync(req.body.password, user.password);
  if (!passwordIsValid) {
    return res.status(401).send({ auth: false, token: null });
  }
  const token = jwt.sign({ id: user.id, role: user.role }, SECRET_KEY, { expiresIn: 86400 }); 
  res.status(200).send({ auth: true, token: token });
});


app.post('/reset-password', (req, res, next) => {
  const user = users.find(u => u.email === req.body.email);
  if (!user) {
    return res.status(404).send('No user found.');
  }
  const newPassword = 'newPassword123';
  user.password = bcrypt.hashSync(newPassword, 8);
  res.status(200).send({ message: 'Password reset successful. Your new password is ' + newPassword });
});

app.use('/users', router);


app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
